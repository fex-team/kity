define({

  msg: '语言包支持'

})
