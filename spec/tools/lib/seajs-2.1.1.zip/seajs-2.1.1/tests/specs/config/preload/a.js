define(function() {
  global.A = 'a'
});
