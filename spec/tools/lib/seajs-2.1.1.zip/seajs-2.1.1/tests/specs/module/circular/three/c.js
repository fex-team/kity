define(function(require, exports) {
  require('./b.js')

  exports.name = 'c'
})