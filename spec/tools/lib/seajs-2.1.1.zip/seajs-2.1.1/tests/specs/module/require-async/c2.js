define({ name: 'c2' });
