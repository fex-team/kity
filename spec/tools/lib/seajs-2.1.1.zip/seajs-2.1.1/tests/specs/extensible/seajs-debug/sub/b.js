define({ name: 'b' });
