
seajs.config({
  base: "./seajs-combo/",
  test: true,
  preload: ["../../../../seajs-combo/dist/seajs-combo-debug"]
})

seajs.use("init")

