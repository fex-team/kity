
seajs.config({
  preload: ["../../../../seajs-health/dist/seajs-health"]
})

seajs.use("./seajs-health/init")

