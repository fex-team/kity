define('z1', [], { name: 'z1' })
define('z2', [], { name: 'z2' })