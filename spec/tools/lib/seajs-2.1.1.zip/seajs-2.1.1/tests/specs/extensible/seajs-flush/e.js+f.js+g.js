define('e', [], { name: 'e' })
define('f', [], { name: 'f' })
define('g', [], { name: 'g' })
