define('b', ['e'], function(require, exports) { require('e'); exports.name = 'b' })
define('c', ['f'], function(require, exports) { require('f'); exports.name = 'c' })
define('d', ['g'], function(require, exports) { require('g'); exports.name = 'd' })
