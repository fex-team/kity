
seajs.config({
  preload: ["../../../../seajs-log/dist/seajs-log"]
})

seajs.use("./seajs-log/init")


