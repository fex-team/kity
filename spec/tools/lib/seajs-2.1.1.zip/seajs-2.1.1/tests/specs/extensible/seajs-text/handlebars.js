define('handlebars', [], function(require, exports) {

  exports.registerHelper = function() {

  }

  exports.compile = function() {
    return function() {
      return '<span>bars</span>'
    }
  }

})
