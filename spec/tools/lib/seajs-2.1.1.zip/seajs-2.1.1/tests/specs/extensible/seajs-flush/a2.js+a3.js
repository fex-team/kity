define('a2', [], { name: 'a2' })
define('a3', [], { name: 'a3' })
