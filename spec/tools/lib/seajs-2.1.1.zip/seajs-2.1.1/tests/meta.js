
// For browsers
var testSuites = [
  'specs/util',

  'specs/config',
  'specs/module',
  'specs/package',
  'specs/extensible',
  'specs/extensible/seajs-debug',
  'specs/extensible/seajs-flush',
  'specs/extensible/seajs-style',

  'specs/misc/bootstrap',
  'specs/misc/callback-order',
  'specs/misc/ie-cache',
  'specs/misc/load-perf',
  'specs/misc/on-error',
  'specs/misc/utf8-in-gbk',
  'specs/misc/x-ua-compatible',

  'research/derive-uri'
]

// For seajs in node
if (typeof define === 'function') {
  define([
    'specs/config',
    'specs/module',
    'specs/package',
    'specs/node'
  ])
}

