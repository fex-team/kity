// extern file for google closure compiler
var console
var seajs
var define
var module
var require
var global
var process